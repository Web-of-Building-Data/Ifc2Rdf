package net.linkedbuildingdata.ifc.util.versioning.structuredmsg;

public enum UpdateType {
	
	Unchanged,
	Added,
	Removed,

}
