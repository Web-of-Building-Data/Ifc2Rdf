package net.linkedbuildingdata.ifc2rdf.web;

import java.util.ArrayList;
import java.util.List;

import net.linkedbuildingdata.common.config.ConfigurationItem;
import net.linkedbuildingdata.common.config.ConfigurationItemEx;
import net.linkedbuildingdata.common.config.ConfigurationPool;
import net.linkedbuildingdata.common.config.document.ConfigurationParserException;
import net.linkedbuildingdata.common.config.document.ConverterPoolConfigurationSection;
import net.linkedbuildingdata.ifc.convert.ifc2rdf.Ifc2RdfConversionContext;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class Ifc2RdfController {
	
	public Ifc2RdfController() {
	}
	
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(@ModelAttribute("model") ModelMap model) throws ConfigurationParserException {
 
        //model.addAttribute("converterOptions", getConverterOptionNames());
 
        return "index";
    }
    
//	private static List<String> getConverterOptionNames()
//			throws ConfigurationParserException {
//		List<String> converterOptionNames = new ArrayList<>();
//
//		ConverterPoolConfigurationSection configurationSection = getConverterPoolConfigurationSection();
//		ConfigurationPool<ConfigurationItemEx> configurationPool = configurationSection
//				.getConfigurationPool();
//		for (ConfigurationItem configurationItem : configurationPool) {
//			converterOptionNames.add(configurationItem.getName());
//		}
//		return converterOptionNames;
//	}    

	private static ConverterPoolConfigurationSection getConverterPoolConfigurationSection()
			throws ConfigurationParserException {
		ConverterPoolConfigurationSection configurationSection = ConverterPoolConfigurationSection
				.getInstance(Ifc2RdfConversionContext.CONFIGURATION_SECTION_CONVERTER_TYPE_NAME);
		return configurationSection;
	}

}
