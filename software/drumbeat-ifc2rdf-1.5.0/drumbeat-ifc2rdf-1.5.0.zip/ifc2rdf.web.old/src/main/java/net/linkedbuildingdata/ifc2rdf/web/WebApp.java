package net.linkedbuildingdata.ifc2rdf.web;

import static spark.Spark.*;


import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import net.linkedbuildingdata.common.cli.LbdOption;
import net.linkedbuildingdata.common.cli.LbdOptionComparator;
import net.linkedbuildingdata.common.config.document.ConfigurationParserException;
import net.linkedbuildingdata.common.config.document.ConverterPoolConfigurationSection;
import net.linkedbuildingdata.ifc.common.IfcVocabulary.IfcCommandLineOptions;
import net.linkedbuildingdata.common.config.*;
import net.linkedbuildingdata.ifc.convert.ifc2rdf.Ifc2RdfConversionContext;
import net.linkedbuildingdata.ifc.convert.ifc2rdf.cli.Ifc2RdfExporter;
import net.linkedbuildingdata.ifc.convert.ifc2rdf.cli.Main;


import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
import org.apache.log4j.Logger;


import spark.ModelAndView;

/**
 * Hello world!
 *
 */
public class WebApp {
	private static final String IFC_TO_RDF_TEMPLATE_FILE = "ifc2rdf.ftl";

	public static final String ATTRIBUTE_CONVERTER_OPTION_NAMES = "converterOptions";
	
	private static boolean isInitialized;

	private static String schemaFolderPath;

	public static void main(String[] args) {
		if (!isInitialized) {
			init(args);
			if (!isInitialized) { // error
				return;
			}
		}
		
		staticFileLocation("/resources");

//		get("/hello", (request, response) -> {
//			return "Hello World!";
//		});

		try {

			get("/ifc2rdf", (request, response) -> {
				Map<String, Object> attributes = new HashMap<>();
				attributes.put("sessionId", request.session().id());
				attributes.put("sessionIsNew", request.session().isNew());
				try {
					loadDataToMap(attributes);
				} catch (Exception e) {
					WebApp.logError(null, e);
					halt(401, "Unexpected error");
				}

				return new ModelAndView(attributes, IFC_TO_RDF_TEMPLATE_FILE);
			}, new FreeMarkerTemplateEngine());
			
			post("/ifc2rdf", (request, response) -> {
				Map<String, String> requestParams = WebApp.parseRequestBody(request.body());
				
				String ifcSchema = requestParams.get("ifcSchema");
				String inputSchemaFilePath = schemaFolderPath +  ifcSchema + ".exp";
				
				String inputModelFilePath = requestParams.get("ifcModel");
				if (inputModelFilePath != null) {
					inputModelFilePath = URLDecoder.decode(inputModelFilePath, "UTF-8");
				}
				
				String outputLayerName = requestParams.get("converterOption");				
				
				String outputSchemaFilePath = requestParams.get("outputIfcSchema");
				if (outputSchemaFilePath != null) {
					outputSchemaFilePath = URLDecoder.decode(outputSchemaFilePath, "UTF-8");
				}

				String outputModelFilePath = requestParams.get("outputIfcModel");
				if (outputModelFilePath != null) {
					outputModelFilePath = URLDecoder.decode(outputModelFilePath, "UTF-8");
				}
				
				String outputFileFormatName = requestParams.get("rdfFormat");
				
				if (requestParams.get("fileCompression").equals("true")) {
					outputFileFormatName += ".GZ";
				}
				
				Ifc2RdfExporter ifc2RdfExporter = new Ifc2RdfExporter(
						inputSchemaFilePath,
						inputModelFilePath,
						outputLayerName,
						outputSchemaFilePath,
						null,
						outputModelFilePath,
						null,
						outputFileFormatName);
				
				ifc2RdfExporter.run();
				
				return "Conversion completed";
			
//				response.header("Pragma", "public"); // required
//				response.header("Expires", "0");
//				response.header("Cache-Control", "must-revalidate, post-check=0, pre-check=0");
//				response.header("Cache-Control", "private"); // required for certain browsers 
//				response.header("Content-Type", "text/plain");
//
//				String fileName = "test123.txt";
//				int fileSize = message.length();
//				
//				response.header("Content-Disposition", "attachment; filename=\"" + fileName + "\";" );
//				response.header("Content-Transfer-Encoding", "binary");
//				response.header("Content-Length", Integer.toString(fileSize));
//				
////				String ifcSchema = (String) request.attribute("ifcSchema");
////				return "ifcSchema: " + ifcSchema;
//				response.body("test123");
				
//				return message;

				//return new ModelAndView(attributes, IFC_TO_RDF_TEMPLATE_FILE);
			})	;


		} catch (Throwable e) {
			WebApp.logError(null, e);
		}
	}
	
	public static Map<String, String> parseRequestBody(String body) {
		Logger.getRootLogger().warn(body);
		
		
		Map<String, String> map = new HashMap<>();
		String[] tokens = body.split("&");
		for (String token : tokens) {
			String[] tokens2 = token.split("=");
			String key = tokens2[0];
			String value = tokens2.length > 1 ? tokens2[1].replaceAll("\\+", " ") : null;
			map.put(key, value);
		}
		return map;
	}
	
	static void logError(String message, Throwable e) {
		Logger logger = Logger.getRootLogger();
		if (logger != null) {
			if (message == null) {
				message = "Unexpected error: " + e.getMessage();
			}
			logger.error(message, e);
		} else {
			e.printStackTrace();
			while ((e = e.getCause()) != null) {
				e.printStackTrace();
			}	
		}		
	}

	private static void init(String[] args) {
		//
		// Define command line options
		//
		Options options = createCommandLineOptions();

		CommandLineParser commandParser = new PosixParser();

		try {
			CommandLine commandLine = commandParser.parse(options, args);

			Ifc2RdfExporter
					.init(commandLine
							.getOptionValue(IfcCommandLineOptions.LOGGER_CONFIG_FILE_SHORT),
							commandLine
									.getOptionValue(IfcCommandLineOptions.CONFIG_FILE_SHORT));

			int portNumber = Integer.parseInt(commandLine
					.getOptionValue(WebAppOptions.PORT_SHORT));
			
			schemaFolderPath = commandLine.getOptionValue(WebAppOptions.SCHEMA_FOLDER_PATH_SHORT) + "\\";

			port(portNumber);

			isInitialized = true;

		} catch (Exception e) {

			Options helpOptions = createHelpOptions();

			try {
				commandParser.parse(helpOptions, args);
			} catch (ParseException e2) {
				// print original error
				System.out.printf("Unexpected error: %s%n%n", e.getMessage());
			}

			printHelp(options, helpOptions);

			return;
		}
	}

	private static void loadDataToMap(Map<String, Object> attributes)
			throws Exception {
		attributes.put(ATTRIBUTE_CONVERTER_OPTION_NAMES,
				getConverterOptionNames());
	}

	private static Options createCommandLineOptions() {

		int index = 0;
		Option option;

		Options options = new Options();

		// option --log-properties-file|-lf <file>
		option = new LbdOption(++index,
				IfcCommandLineOptions.LOGGER_CONFIG_FILE_SHORT,
				IfcCommandLineOptions.LOGGER_CONFIG_FILE_LONG, true,
				IfcCommandLineOptions.LOGGER_CONFIG_FILE_DESCRIPTION);
		option.setArgName(IfcCommandLineOptions.ARG_FILE);
		option.setRequired(true);
		options.addOption(option);

		// option --config-file|-cf <file>
		option = new LbdOption(++index,
				IfcCommandLineOptions.CONFIG_FILE_SHORT,
				IfcCommandLineOptions.CONFIG_FILE_LONG, true,
				IfcCommandLineOptions.CONFIG_FILE_DESCRIPTION);
		option.setArgName(IfcCommandLineOptions.ARG_FILE);
		option.setRequired(true);
		options.addOption(option);

		// option --port|-p <file>
		option = new LbdOption(++index, WebAppOptions.PORT_SHORT,
				WebAppOptions.PORT_LONG, true, WebAppOptions.PORT_DESCRIPTION);
		option.setArgName(IfcCommandLineOptions.ARG_NAME);
		option.setRequired(true);
		options.addOption(option);

		// option --schema-folder-path|-sfp <file>
		option = new LbdOption(++index, WebAppOptions.SCHEMA_FOLDER_PATH_SHORT,
				WebAppOptions.SCHEMA_FOLDER_PATH_LONG, true, WebAppOptions.SCHEMA_FOLDER_PATH_DESCRIPTION);
		option.setArgName(IfcCommandLineOptions.ARG_FILE);
		option.setRequired(true);
		options.addOption(option);

		
		// // option --output-layer-name|-oln <name>
		// option = new LbdOption(
		// ++index,
		// IfcCommandLineOptions.OUTPUT_LAYER_NAME_SHORT,
		// IfcCommandLineOptions.OUTPUT_LAYER_NAME_LONG,
		// true,
		// IfcCommandLineOptions.OUTPUT_LAYER_NAME_DESCRIPTION);
		// option.setArgName(IfcCommandLineOptions.ARG_FILE);
		// option.setRequired(true);
		// options.addOption(option);
		//
		// // option --input-schema-file|-isf <file>
		// option = new LbdOption(
		// ++index,
		// IfcCommandLineOptions.INPUT_SCHEMA_FILE_SHORT,
		// IfcCommandLineOptions.INPUT_SCHEMA_FILE_LONG,
		// true,
		// IfcCommandLineOptions.INPUT_SCHEMA_FILE_DESCRIPTION);
		// option.setArgName(IfcCommandLineOptions.ARG_FILE);
		// option.setRequired(true);
		// options.addOption(option);
		//
		// // option --input-model-file|-imf <file>
		// option = new LbdOption(
		// ++index,
		// IfcCommandLineOptions.INPUT_MODEL_FILE_1_SHORT,
		// IfcCommandLineOptions.INPUT_MODEL_FILE_LONG,
		// true,
		// IfcCommandLineOptions.INPUT_MODEL_FILE_DESCRIPTION);
		// option.setArgName(IfcCommandLineOptions.ARG_FILE);
		// option.setRequired(false);
		// options.addOption(option);
		//
		// OptionGroup optionGroup = new OptionGroup();
		//
		//
		// // option --output-schema-file|-osf <name>
		// option = new LbdOption(
		// ++index,
		// IfcCommandLineOptions.OUTPUT_SCHEMA_NAME_SHORT,
		// IfcCommandLineOptions.OUTPUT_SCHEMA_NAME_LONG,
		// true,
		// IfcCommandLineOptions.OUTPUT_SCHEMA_NAME_DESCRIPTION +
		// IfcCommandLineOptions.SUFFIX_OPTIONAL);
		// option.setArgName(IfcCommandLineOptions.ARG_NAME);
		// optionGroup.addOption(option);
		//
		// // option --output-schema-file|-osf <file>
		// option = new LbdOption(
		// ++index,
		// IfcCommandLineOptions.OUTPUT_SCHEMA_FILE_SHORT,
		// IfcCommandLineOptions.OUTPUT_SCHEMA_FILE_LONG,
		// true,
		// IfcCommandLineOptions.OUTPUT_SCHEMA_FILE_DESCRIPTION +
		// IfcCommandLineOptions.SUFFIX_OPTIONAL);
		// option.setArgName(IfcCommandLineOptions.ARG_FILE);
		// optionGroup.addOption(option);
		//
		//
		// optionGroup.setRequired(false);
		// options.addOptionGroup(optionGroup);
		//
		//
		//
		// optionGroup = new OptionGroup();
		//
		// // option --output-model-name|-omf <name>
		// option = new LbdOption(
		// ++index,
		// IfcCommandLineOptions.OUTPUT_MODEL_NAME_1_SHORT,
		// IfcCommandLineOptions.OUTPUT_MODEL_NAME_LONG,
		// true,
		// IfcCommandLineOptions.OUTPUT_MODEL_NAME_DESCRIPTION +
		// IfcCommandLineOptions.SUFFIX_OPTIONAL);
		// option.setArgName(IfcCommandLineOptions.ARG_NAME);
		// optionGroup.addOption(option);
		//
		// // option --output-model-file|-omf <file>
		// option = new LbdOption(
		// ++index,
		// IfcCommandLineOptions.OUTPUT_MODEL_FILE_1_SHORT,
		// IfcCommandLineOptions.OUTPUT_MODEL_FILE_LONG,
		// true,
		// IfcCommandLineOptions.OUTPUT_MODEL_FILE_DESCRIPTION +
		// IfcCommandLineOptions.SUFFIX_OPTIONAL);
		// option.setArgName(IfcCommandLineOptions.ARG_FILE);
		// optionGroup.addOption(option);
		//
		// optionGroup.setRequired(false);
		// options.addOptionGroup(optionGroup);
		//
		// // option --config-file|-cf <file>
		// option = new LbdOption(
		// ++index,
		// IfcCommandLineOptions.OUTPUT_FILE_FORMAT_SHORT,
		// IfcCommandLineOptions.OUTPUT_FILE_FORMAT_LONG,
		// true,
		// IfcCommandLineOptions.OUTPUT_FILE_FORMAT_DESCRIPTION);
		// option.setArgName(IfcCommandLineOptions.ARG_NAME);
		// option.setRequired(false);
		// options.addOption(option);
		return options;
	}

	private static Options createHelpOptions() {
		Options options = new Options();
		Option option = new Option(IfcCommandLineOptions.HELP_SHORT,
				IfcCommandLineOptions.HELP_LONG, false,
				IfcCommandLineOptions.HELP_DESCRIPTION);
		option.setRequired(true);
		options.addOption(option);
		return options;
	}

	private static void printHelp(Options options, Options helpOptions) {
		HelpFormatter helpFormatter = new HelpFormatter();
		String className = Main.class.getName();
		helpFormatter.printHelp(className, helpOptions, true);
		helpFormatter.setOptionComparator(new LbdOptionComparator());
		helpFormatter.printHelp(IfcCommandLineOptions.FORMATTER_WIDTH,
				className, null, options, null, true);
	}

	private static ConverterPoolConfigurationSection getConverterPoolConfigurationSection()
			throws ConfigurationParserException {
		ConverterPoolConfigurationSection configurationSection = ConverterPoolConfigurationSection
				.getInstance(Ifc2RdfConversionContext.CONFIGURATION_SECTION_CONVERTER_TYPE_NAME);
		return configurationSection;
	}

	private static List<String> getConverterOptionNames()
			throws ConfigurationParserException {
		List<String> converterOptionNames = new ArrayList<>();

		ConverterPoolConfigurationSection configurationSection = getConverterPoolConfigurationSection();
		ConfigurationPool<ConfigurationItemEx> configurationPool = configurationSection
				.getConfigurationPool();
		for (ConfigurationItem configurationItem : configurationPool) {
			converterOptionNames.add(configurationItem.getName());
		}
		return converterOptionNames;
	}

}
