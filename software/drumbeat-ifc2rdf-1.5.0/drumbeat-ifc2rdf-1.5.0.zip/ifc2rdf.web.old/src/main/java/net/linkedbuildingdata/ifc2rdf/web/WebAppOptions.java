package net.linkedbuildingdata.ifc2rdf.web;

public class WebAppOptions {
	
	public static final String PORT_SHORT = "p";
	public static final String PORT_LONG = "port";
	public static final String PORT_DESCRIPTION = "Port number";
	public static final String PORT_DEFAULT = "80";
	
	public static final String SCHEMA_FOLDER_PATH_SHORT = "sfp";
	public static final String SCHEMA_FOLDER_PATH_LONG = "schema-folder-path";
	public static final String SCHEMA_FOLDER_PATH_DESCRIPTION = "Schema folder path";
	
	
	
}
