package net.linkedbuildingdata.rdf.versioning;


import net.linkedbuildingdata.common.cli.LbdOption;
import net.linkedbuildingdata.common.cli.LbdOptionComparator;
import net.linkedbuildingdata.ifc.common.IfcVocabulary.IfcCommandLineOptions;

import org.apache.commons.cli.*;
import org.apache.log4j.Logger;

public class Main {

	/**
	 * @param args
	 * @param groundingRuleSetName 
	 */
	public static void main(String[] args) {
		
		
		//
		// Define command line options 
		//
		Options options = createCommandLineOptions();
		Logger logger = Logger.getRootLogger();
		CommandLineParser commandParser = new PosixParser();
		
		try {
			
			//
			// Parse command line 
			//
			CommandLine commandLine = commandParser.parse(options, args);
			
			String loggerConfigFilePath = commandLine.getOptionValue(IfcCommandLineOptions.LOGGER_CONFIG_FILE_SHORT); 
			String configFilePath = commandLine.getOptionValue(IfcCommandLineOptions.CONFIG_FILE_SHORT);
			String inputSchemaFilePath = commandLine.getOptionValue(IfcCommandLineOptions.INPUT_SCHEMA_FILE_SHORT);
			String inputModelFilePath1 = commandLine.getOptionValue(IfcCommandLineOptions.INPUT_MODEL_FILE_1_SHORT);
			String inputModelFilePath2 = commandLine.getOptionValue(IfcCommandLineOptions.INPUT_MODEL_FILE_2_SHORT);
			String outputSchemaFilePath = commandLine.getOptionValue(IfcCommandLineOptions.OUTPUT_SCHEMA_FILE_SHORT);
			String outputSchemaName = commandLine.getOptionValue(IfcCommandLineOptions.OUTPUT_SCHEMA_NAME_SHORT);
			String outputModelFilePath1 = commandLine.getOptionValue(IfcCommandLineOptions.OUTPUT_MODEL_FILE_1_SHORT);
			String outputModelName1 = commandLine.getOptionValue(IfcCommandLineOptions.OUTPUT_MODEL_NAME_1_SHORT);
			String outputModelFilePath2 = commandLine.getOptionValue(IfcCommandLineOptions.OUTPUT_MODEL_FILE_2_SHORT);
			String outputModelName2 = commandLine.getOptionValue(IfcCommandLineOptions.OUTPUT_MODEL_NAME_2_SHORT);
			String outputFileFormatName = commandLine.getOptionValue(IfcCommandLineOptions.OUTPUT_FILE_FORMAT_SHORT, IfcCommandLineOptions.OUTPUT_FILE_FORMAT_DEFAULT);			
			
			boolean compareModels = commandLine.hasOption(IfcCommandLineOptions.COMPARE_MODELS_SHORT); 
			String compareModelDirectory = commandLine.getOptionValue(IfcCommandLineOptions.COMPARE_MODELS_DIR_SHORT);
			String groundingRuleSetName = commandLine.getOptionValue(IfcCommandLineOptions.GROUNDING_RULE_SET_SHORT);
			

			//
			// Export schema and models
			//
			Ifc2RdfExporter exporter = new Ifc2RdfExporter(
				 loggerConfigFilePath,
				 configFilePath,
				 inputSchemaFilePath,
				 inputModelFilePath1,
				 inputModelFilePath2,
				 outputSchemaFilePath,
				 outputSchemaName,
				 outputModelFilePath1,
				 outputModelName1,
				 outputModelFilePath2,
				 outputModelName2,
				 outputFileFormatName,
				 groundingRuleSetName);
			
			exporter.run();
			
			//
			// Compare models
			//
			if (compareModels && compareModelDirectory != null) {
				
				if (groundingRuleSetName == null) {
					groundingRuleSetName = exporter.getGroundingRuleSetName();
				}
				
				Ifc2RdfComparer comparer = new Ifc2RdfComparer(
						exporter.getJenaModels(),
						exporter.getModelNames(),
						compareModelDirectory,
						groundingRuleSetName);
				comparer.run();
			}

		} catch (ParseException e) {
			
			Options helpOptions = createHelpOptions();			
			
			try {				
				commandParser.parse(helpOptions, args);				
			} catch (ParseException e2) {
				// print original error
				System.out.printf("Unexpected error: %s%n%n", e.getMessage());
			}
			
			printHelp(options, helpOptions);
			
			return;
			
		} catch (Throwable e) {
			if (logger != null) {
				logger.error("Unexpected error: " + e.getMessage(), e);
			} else {
				e.printStackTrace();
				while ((e = e.getCause()) != null) {
					e.printStackTrace();
				}	
			}
		}
		
		logger.info("END OF PROGRAM");
	}

	private static Options createCommandLineOptions() {
		
		int index = 0;
		Option option;
		
		Options options = new Options();
		
		// option --log-properties-file|-lf <file>
		option = new LbdOption(
				++index,
				IfcCommandLineOptions.LOGGER_CONFIG_FILE_SHORT,
				IfcCommandLineOptions.LOGGER_CONFIG_FILE_LONG,
				true,
				IfcCommandLineOptions.LOGGER_CONFIG_FILE_DESCRIPTION);
		option.setArgName(IfcCommandLineOptions.ARG_FILE);
		option.setRequired(true);
		options.addOption(option);
		
		// option --config-file|-cf <file>
		option = new LbdOption(
				++index,
				IfcCommandLineOptions.CONFIG_FILE_SHORT,
				IfcCommandLineOptions.CONFIG_FILE_LONG,
				true,
				IfcCommandLineOptions.CONFIG_FILE_DESCRIPTION);
		option.setArgName(IfcCommandLineOptions.ARG_FILE);
		option.setRequired(true);
		options.addOption(option);

		// option --input-schema-file|-isf <file>
		option = new LbdOption(
				++index,
				IfcCommandLineOptions.INPUT_SCHEMA_FILE_SHORT,
				IfcCommandLineOptions.INPUT_SCHEMA_FILE_LONG,
				true,
				IfcCommandLineOptions.INPUT_SCHEMA_FILE_DESCRIPTION);
		option.setArgName(IfcCommandLineOptions.ARG_FILE);
		option.setRequired(true);
		options.addOption(option);
		
		// option --input-model-file|-imf <file>
		option = new LbdOption(
				++index,
				IfcCommandLineOptions.INPUT_MODEL_FILE_1_SHORT,
				IfcCommandLineOptions.INPUT_MODEL_FILE_LONG,
				true,
				IfcCommandLineOptions.INPUT_MODEL_FILE_DESCRIPTION);
		option.setArgName(IfcCommandLineOptions.ARG_FILE);
		option.setRequired(false);
		options.addOption(option);		
		
		// option --input-model-file-2|-imf-2 <file>
		option = new LbdOption(
				++index,
				IfcCommandLineOptions.INPUT_MODEL_FILE_2_SHORT,
				IfcCommandLineOptions.INPUT_MODEL_FILE_2_LONG,
				true,
				IfcCommandLineOptions.INPUT_MODEL_FILE_2_DESCRIPTION);
		option.setArgName(IfcCommandLineOptions.ARG_FILE);
		option.setRequired(false);
		options.addOption(option);		

		
		OptionGroup optionGroup = new OptionGroup();
		

		// option --output-schema-file|-osf <name>
		option = new LbdOption(
				++index,
				IfcCommandLineOptions.OUTPUT_SCHEMA_NAME_SHORT,
				IfcCommandLineOptions.OUTPUT_SCHEMA_NAME_LONG,
				true,
				IfcCommandLineOptions.OUTPUT_SCHEMA_NAME_DESCRIPTION + IfcCommandLineOptions.SUFFIX_OPTIONAL);
		option.setArgName(IfcCommandLineOptions.ARG_NAME);
		optionGroup.addOption(option);
		
		// option --output-schema-file|-osf <file>
		option = new LbdOption(
				++index,
				IfcCommandLineOptions.OUTPUT_SCHEMA_FILE_SHORT,
				IfcCommandLineOptions.OUTPUT_SCHEMA_FILE_LONG,
				true,
				IfcCommandLineOptions.OUTPUT_SCHEMA_FILE_DESCRIPTION + IfcCommandLineOptions.SUFFIX_OPTIONAL);
		option.setArgName(IfcCommandLineOptions.ARG_FILE);
		optionGroup.addOption(option);


		optionGroup.setRequired(false);		
		options.addOptionGroup(optionGroup);
		
		
		
		optionGroup = new OptionGroup();

		// option --output-model-name|-omf <name>
		option = new LbdOption(
				++index,
				IfcCommandLineOptions.OUTPUT_MODEL_NAME_1_SHORT,
				IfcCommandLineOptions.OUTPUT_MODEL_NAME_LONG,
				true,
				IfcCommandLineOptions.OUTPUT_MODEL_NAME_DESCRIPTION  + IfcCommandLineOptions.SUFFIX_OPTIONAL);
		option.setArgName(IfcCommandLineOptions.ARG_NAME);
		optionGroup.addOption(option);
		
		// option --output-model-file|-omf <file>
		option = new LbdOption(
				++index,
				IfcCommandLineOptions.OUTPUT_MODEL_FILE_1_SHORT,
				IfcCommandLineOptions.OUTPUT_MODEL_FILE_LONG,
				true,
				IfcCommandLineOptions.OUTPUT_MODEL_FILE_DESCRIPTION  + IfcCommandLineOptions.SUFFIX_OPTIONAL);
		option.setArgName(IfcCommandLineOptions.ARG_FILE);
		optionGroup.addOption(option);
		
		optionGroup.setRequired(false);		
		options.addOptionGroup(optionGroup);
		
		
		
		optionGroup = new OptionGroup();

		// option --output-model-name-2|-omf2 <name>
		option = new LbdOption(
				++index,
				IfcCommandLineOptions.OUTPUT_MODEL_NAME_2_SHORT,
				IfcCommandLineOptions.OUTPUT_MODEL_NAME_2_LONG,
				true,
				IfcCommandLineOptions.OUTPUT_MODEL_NAME_2_DESCRIPTION  + IfcCommandLineOptions.SUFFIX_OPTIONAL);
		option.setArgName(IfcCommandLineOptions.ARG_NAME);
		optionGroup.addOption(option);
		
		// option --output-model-file-2|-omf2 <file>
		option = new LbdOption(
				++index,
				IfcCommandLineOptions.OUTPUT_MODEL_FILE_2_SHORT,
				IfcCommandLineOptions.OUTPUT_MODEL_FILE_2_LONG,
				true,
				IfcCommandLineOptions.OUTPUT_MODEL_FILE_2_DESCRIPTION  + IfcCommandLineOptions.SUFFIX_OPTIONAL);
		option.setArgName(IfcCommandLineOptions.ARG_FILE);
		optionGroup.addOption(option);
		
		optionGroup.setRequired(false);		
		options.addOptionGroup(optionGroup);
		
		
		// option --output-file-language|-ofl <name>
		option = new LbdOption(
				++index,
				IfcCommandLineOptions.OUTPUT_FILE_FORMAT_SHORT,
				IfcCommandLineOptions.OUTPUT_FILE_FORMAT_LONG,
				true,
				IfcCommandLineOptions.OUTPUT_FILE_FORMAT_DESCRIPTION);
		option.setArgName(IfcCommandLineOptions.ARG_NAME);
		option.setRequired(false);
		options.addOption(option);
		
		// option --grounding-rule-set|-grs <name>
		option = new LbdOption(
				++index,
				IfcCommandLineOptions.GROUNDING_RULE_SET_SHORT,
				IfcCommandLineOptions.GROUNDING_RULE_SET_LONG,
				true,
				IfcCommandLineOptions.GROUNDING_RULE_SET_DESCRIPTION);
		option.setArgName(IfcCommandLineOptions.ARG_NAME);
		option.setRequired(false);
		options.addOption(option);		
		
		
		// option --compare-models|-cpm
		option = new LbdOption(
				++index,
				IfcCommandLineOptions.COMPARE_MODELS_SHORT,
				IfcCommandLineOptions.COMPARE_MODELS_LONG,
				false,
				IfcCommandLineOptions.COMPARE_MODELS_DESCRIPTION);
		option.setRequired(false);
		options.addOption(option);
		
		// option --compare-models-dir|-cpd
		option = new LbdOption(
				++index,
				IfcCommandLineOptions.COMPARE_MODELS_DIR_SHORT,
				IfcCommandLineOptions.COMPARE_MODELS_DIR_LONG,
				true,
				IfcCommandLineOptions.COMPARE_MODELS_DIR_DESCRIPTION);
		option.setArgName(IfcCommandLineOptions.ARG_DIR);
		option.setRequired(false);
		options.addOption(option);

		return options;
	}
	
	private static Options createHelpOptions() {
		Options options = new Options();
		Option option = new Option(
				IfcCommandLineOptions.HELP_SHORT,
				IfcCommandLineOptions.HELP_LONG,
				false,
				IfcCommandLineOptions.HELP_DESCRIPTION);
		option.setRequired(true);
		options.addOption(option);
		return options;
	}
	
	private static void printHelp(Options options, Options helpOptions) {		
		HelpFormatter helpFormatter = new HelpFormatter();
		String className = Main.class.getName();
		helpFormatter.printHelp(className, helpOptions, true);
		helpFormatter.setOptionComparator(new LbdOptionComparator());
		helpFormatter.printHelp(IfcCommandLineOptions.FORMATTER_WIDTH, className, null, options, null, true);
	}

	
}
