package net.linkedbuildingdata.rdf.versioning;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import util.IfcModelAnalyzerUtil;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;

import net.linkedbuildingdata.common.file.FileManager;
import net.linkedbuildingdata.common.string.StringUtils;
import net.linkedbuildingdata.rdf.RdfUtils;
import net.linkedbuildingdata.rdf.data.IRdfModel;
import net.linkedbuildingdata.rdf.data.adapters.JenaModelAdapter;
import net.linkedbuildingdata.rdf.data.msg.RdfMsg;
import net.linkedbuildingdata.rdf.data.msg.RdfMsgContainer;
import net.linkedbuildingdata.rdf.data.msg.RdfTree;

public class Ifc2RdfComparer {
	
	private static final Logger logger = Logger.getRootLogger();

	private Model[] jenaModels;
	private String[] modelNames;
	private String compareModelDir;
	private String groundRuleSetName;
	
	public Ifc2RdfComparer(			
			Model[] jenaModels,
			String[] modelNames,
			String compareModelDirectory,
			String groundRuleSetName) {
		
		this.jenaModels = jenaModels;
		this.modelNames = modelNames;
		this.compareModelDir = compareModelDirectory;
		this.groundRuleSetName = groundRuleSetName;
	}
	
	public void run() throws Exception {
		
		int numberOfModels = jenaModels.length;		
		
		//
		// compare models
		//
		File compareOutputDirectory = null;				
		if (!StringUtils.isEmptyOrNull(compareModelDir)) {					
			compareOutputDirectory = FileManager.createDirectory(compareModelDir);
			
			if (!StringUtils.isEmptyOrNull(groundRuleSetName)) {
				compareOutputDirectory = FileManager.createDirectory(FileManager.createFileName(compareOutputDirectory, groundRuleSetName));
			}
		}
		
		//
		// export to structured MSG container (model 1)
		//
		IRdfModel[] rdfModels = new IRdfModel[numberOfModels];
		RdfMsgContainer[] rdfMsgContainers = new RdfMsgContainer[numberOfModels];
		
		for (int i = 0; i < numberOfModels; ++i) {
			rdfModels[i] = new JenaModelAdapter(jenaModels[i]);
			rdfMsgContainers[i] = IfcModelAnalyzerUtil.splitToStructuredMsgs(rdfModels[i]);
			
			if (compareOutputDirectory != null) {						
				File modelDirectory = FileManager.createDirectory(FileManager.createFileName(compareOutputDirectory, modelNames[i]));
				logger.info(String.format("Exporting statistics of model '%s' (%,d triples) to folder '%s'", modelNames[i], jenaModels[i].size(), modelDirectory.getAbsoluteFile()));
				IfcModelAnalyzerUtil.exportStructuredMsgs(rdfMsgContainers[i], FileManager.createFileName(modelDirectory, "structuredMsgs_%s.txt"));
				IfcModelAnalyzerUtil.exportStructuredMsgsStatistics(rdfMsgContainers[i], FileManager.createFileName(modelDirectory, "structuredMsgs_statistics.txt"));
			}
		}
		
		if (compareOutputDirectory != null && numberOfModels > 1) {
			
			for (int i = 0; i < numberOfModels - 1; ++i) {
				int j = i + 1;
				File modelsCompareOutputDirectory = FileManager.createDirectory(FileManager.createFileName(compareOutputDirectory,
						String.format("%s vs %s", modelNames[i], modelNames[j])));
				
				logger.info(String.format("Comparing versions %d and %d, output folder: %s", i, j, modelsCompareOutputDirectory.getAbsolutePath()));
				IfcModelAnalyzerUtil.compareVersions(rdfMsgContainers[i], rdfMsgContainers[j], FileManager.createFileName(modelsCompareOutputDirectory, "%%s_%s.txt"));
				logger.info(String.format("Comparing versions %d and %d is complleted", i, j));
			}
			
		}
		
	}	
	

}
