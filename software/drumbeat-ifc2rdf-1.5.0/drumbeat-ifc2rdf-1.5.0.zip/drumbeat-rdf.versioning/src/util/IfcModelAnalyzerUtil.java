package util;

import java.io.FileWriter;
import java.io.IOException;

import net.linkedbuildingdata.common.config.ComplexProcessorConfiguration;
import net.linkedbuildingdata.common.config.ComplexProcessorConfigurationPool;
import net.linkedbuildingdata.common.config.document.ConfigurationParserException;
import net.linkedbuildingdata.common.string.StringUtils;
import net.linkedbuildingdata.ifc.IfcException;
import net.linkedbuildingdata.ifc.data.model.IfcModel;
import net.linkedbuildingdata.ifc.util.IfcModelAnalyser;
import net.linkedbuildingdata.ifc.util.decomposing.IfcModelSplitter;
import net.linkedbuildingdata.ifc.util.decomposing.msg.RdfMsgExporter;
import net.linkedbuildingdata.ifc.util.decomposing.msg.RdfMsgStatisticsExporter;
import net.linkedbuildingdata.ifc.util.grounding.config.IfcGroundingProcessorPoolConfigurationSection;
import net.linkedbuildingdata.ifc.util.versioning.structuredmsg.StructuredMsgContainerUpdate;
import net.linkedbuildingdata.ifc.util.versioning.structuredmsg.StructuredMsgContainerUpdateExporter;
import net.linkedbuildingdata.rdf.RdfException;
import net.linkedbuildingdata.rdf.data.IRdfModel;
import net.linkedbuildingdata.rdf.data.msg.RdfMsgContainer;

import org.apache.log4j.Logger;


public class IfcModelAnalyzerUtil {

	private static final Logger logger = Logger.getLogger(IfcModelAnalyzerUtil.class);	

	public static ComplexProcessorConfiguration getDefaultGroundingRuleSet() throws ConfigurationParserException {
		
		return getGroundingRuleSet(null);
		
	}
	
	/**
	 * Loads the grounding rule set from the configuration document
	 * @param groundingRuleSetName The name of the grounding rule set (if null then the default set will be returned) 
	 * @return the grounding rule set (must be enabled in the configuration document) with the specified name 
	 * @throws ConfigurationParserException
	 */
	public static ComplexProcessorConfiguration getGroundingRuleSet(String groundingRuleSetName) throws ConfigurationParserException {
		
		IfcGroundingProcessorPoolConfigurationSection groundingProcessorPoolConfigurationSection = IfcGroundingProcessorPoolConfigurationSection.getInstance();
		
		ComplexProcessorConfigurationPool groundingComplexProcessorConfigurationPool = groundingProcessorPoolConfigurationSection.getComplexProcessorConfigurationPool();
		
		ComplexProcessorConfiguration groundingComplexProcessorConfiguration;
		
		if (StringUtils.isEmptyOrNull(groundingRuleSetName)) {
			groundingComplexProcessorConfiguration = groundingComplexProcessorConfigurationPool.getDefault();			
		} else {
			groundingComplexProcessorConfiguration = groundingComplexProcessorConfigurationPool.getByName(groundingRuleSetName);
		}
		
		return groundingComplexProcessorConfiguration;
	}
	
	
	public static void groundModel(IfcModel model, ComplexProcessorConfiguration groundingConfiguration) throws IfcException {
		IfcModelAnalyser analyser = new IfcModelAnalyser(model);
		logger.info(String.format("Applying set of grounding rules '%s'", groundingConfiguration.getName()));
		analyser.groundNodes(groundingConfiguration);
	}
	
	public static RdfMsgContainer splitToStructuredMsgs(IRdfModel model) throws RdfException {
		logger.info("Splitting model to structured MSGs");
		
		RdfMsgContainer msgContainer = IfcModelSplitter.split(model);		
		logger.info(
				String.format("Splitting model to structured MSGs has been completed successfully (%d MSGs)", msgContainer.getTotalSize()));
		return msgContainer;
	}
	
	public static void exportStructuredMsgs(RdfMsgContainer rdfMsgContainer, String fileNameFormat) throws Exception {
	
		logger.info("Exporting structured MSGs to text file");
		try {
			RdfMsgExporter.export(rdfMsgContainer, fileNameFormat);
			logger.info("Exporting structured MSGs has been completed successfully");
		} catch (Exception e) {
			logger.error("Error exporting structured MSGs", e);
			throw e;
		}
		
	}

	public static void exportStructuredMsgsStatistics(RdfMsgContainer rdfMsgContainer, String filePath) throws Exception {
		
		logger.info("Exporting statistical data of structured MSGs to text file");
		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter(filePath);
			RdfMsgStatisticsExporter.export(rdfMsgContainer, fileWriter);
			logger.info("Exporting statistical data of structured MSGs has been completed successfully");
		} catch (Exception e) {
			logger.error("Error exporting structured MSGs", e);
			throw e;
		} finally {
			if (fileWriter != null) {
				fileWriter.close();
			}
		}
		
	}
	
	

	public static void compareVersions(
		RdfMsgContainer structuredMsgContainer1,
		RdfMsgContainer structuredMsgContainer2,
		String fileNameFormat) throws IOException, RdfException {
	
		StructuredMsgContainerUpdate structuredMsgContainerUpdate = new StructuredMsgContainerUpdate(structuredMsgContainer1, structuredMsgContainer2);	
		StructuredMsgContainerUpdateExporter.export(structuredMsgContainerUpdate, fileNameFormat); 
		
	}

	

	

}
