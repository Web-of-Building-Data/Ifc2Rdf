package net.linkedbuildingdata.common.config;

public class ComplexProcessorConfigurationPool extends ConfigurationPool<ComplexProcessorConfiguration> {

	private static final long serialVersionUID = 1L;

}
