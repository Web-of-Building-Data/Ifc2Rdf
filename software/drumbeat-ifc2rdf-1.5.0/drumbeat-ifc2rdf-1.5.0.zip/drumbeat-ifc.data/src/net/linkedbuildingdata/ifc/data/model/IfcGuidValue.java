package net.linkedbuildingdata.ifc.data.model;

import net.linkedbuildingdata.ifc.common.guid.Guid;
import net.linkedbuildingdata.ifc.common.guid.GuidCompressor;
import net.linkedbuildingdata.ifc.data.schema.IfcTypeEnum;

public class IfcGuidValue extends IfcLiteralValue {

	private static final long serialVersionUID = 1L;

	public IfcGuidValue(Object value) {
		super(value, IfcTypeEnum.GUID);
	}
	
	public String getShortGuidId() {
		return super.getValue().toString();
	}
	
	public Guid getStandardGuid() {
		Guid guid = new Guid();
		GuidCompressor.getGuidFromCompressedString(getShortGuidId(), guid);
		return guid;
	}

}
