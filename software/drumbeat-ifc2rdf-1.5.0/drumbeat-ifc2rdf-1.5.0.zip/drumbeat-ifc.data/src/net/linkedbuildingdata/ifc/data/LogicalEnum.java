package net.linkedbuildingdata.ifc.data;

public enum LogicalEnum {	
	TRUE,
	FALSE,
	UNKNOWN,
}
