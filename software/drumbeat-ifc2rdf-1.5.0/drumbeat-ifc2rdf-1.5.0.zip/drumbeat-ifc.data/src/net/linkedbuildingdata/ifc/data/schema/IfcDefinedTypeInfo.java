package net.linkedbuildingdata.ifc.data.schema;

public abstract class IfcDefinedTypeInfo extends IfcTypeInfo {

	private static final long serialVersionUID = 1L;

	public IfcDefinedTypeInfo(IfcSchema schema, String name) {
		super(schema, name);
	}

}
