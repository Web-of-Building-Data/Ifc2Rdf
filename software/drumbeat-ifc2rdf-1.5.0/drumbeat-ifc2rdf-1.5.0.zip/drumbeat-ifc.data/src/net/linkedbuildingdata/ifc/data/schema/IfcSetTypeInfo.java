package net.linkedbuildingdata.ifc.data.schema;

public class IfcSetTypeInfo extends IfcCollectionTypeInfo {

	private static final long serialVersionUID = 1L;

	public IfcSetTypeInfo(IfcSchema schema, String typeName, String itemTypeInfoName) {
		super(schema, typeName, itemTypeInfoName);
	}

	@Override
	public boolean isSorted() {
		return false;
	}

	@Override
	public boolean isLiteralContainerType() {
		return getItemTypeInfo().isLiteralContainerType();
	}

}
