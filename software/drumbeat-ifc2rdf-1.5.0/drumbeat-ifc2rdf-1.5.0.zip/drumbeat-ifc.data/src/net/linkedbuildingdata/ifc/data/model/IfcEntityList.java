package net.linkedbuildingdata.ifc.data.model;

import java.util.List;

public class IfcEntityList extends IfcListValue<IfcEntityBase> {

	private static final long serialVersionUID = 1L;

	public IfcEntityList() {
	}

	public IfcEntityList(List<IfcEntityBase> values) {
		super(values);
	}

	@Override
	public Boolean isLiteralType() {
		return false;
	}

}
