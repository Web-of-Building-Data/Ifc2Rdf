import java.io.File;
import java.io.FileWriter;
import java.util.*;
import java.util.Map.Entry;

import net.linkedbuildingdata.common.collections.Pair;
import net.linkedbuildingdata.common.config.*;
import net.linkedbuildingdata.common.config.document.*;
import net.linkedbuildingdata.common.file.FileManager;
import net.linkedbuildingdata.common.string.RegexUtils;
import net.linkedbuildingdata.ifc.convert.ifc2rdf.util.Ifc2BinaryFileExportUtil;
import net.linkedbuildingdata.ifc.convert.step2ifc.util.IfcParserUtil;
import net.linkedbuildingdata.ifc.data.model.IfcModel;
import net.linkedbuildingdata.ifc.data.schema.*;
import net.linkedbuildingdata.ifc.convert.ifc2rdf.util.Ifc2RdfExportUtil;
import net.linkedbuildingdata.rdf.data.msg.RdfMsgContainer;
import net.linkedbuildingdata.rdf.modelfactory.JenaModelFactoryBase;
import net.linkedbuildingdata.rdf.modelfactory.config.JenaModelFactoryPoolConfigurationSection;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.xml.DOMConfigurator;

import util.*;

import com.hp.hpl.jena.rdf.model.Model;


public class Main {

	private static final String ARG_LOGGER_PROPERTIES = "-log";
	private static final String ARG_LOGGER_PROPERTIES_SHORT = "-l";
	private static final String ARG_CONFIG = "-config";
	private static final String ARG_CONFIG_SHORT = "-c";
	private static final String ARG_SCHEMA = "-schema";
	private static final String ARG_SCHEMA_SHORT = "-s";
	private static final String ARG_MODEL = "-model";
	private static final String ARG_MODEL_SHORT = "-m";
	private static final String ARG_MODEL2 = "-model2";
	private static final String ARG_MODEL2_SHORT = "-m2";
	
	private static final boolean RELOAD_DATA_FROM_DATABASE = true;
	
	private static final String ARG_SYNTAX = String.format(
			"Usage: %s %s|%s <logPropertiesFile> %s|%s <configFile> %s|%s <schemaFile> %s|%s <modelFile> %s|%s <modelFile>",
			//Main.class.getProtectionDomain().getCodeSource().getLocation().getFile(),
			//Main.class.getResource("").getPath(),
			"Main",
			ARG_LOGGER_PROPERTIES,
			ARG_LOGGER_PROPERTIES_SHORT,
			ARG_CONFIG,
			ARG_CONFIG_SHORT,
			ARG_SCHEMA,
			ARG_SCHEMA_SHORT,
			ARG_MODEL,
			ARG_MODEL_SHORT,
			ARG_MODEL2,
			ARG_MODEL2_SHORT);
	
	private static final Logger logger = Logger.getRootLogger();
	
	private JenaModelFactoryBase jenaModelFactoryBase;
	private String loggerPropertiesFilePath;
	private String configFilePath;
	private String schemaFilePath;
	private String modelFilePath;
	private String modelFilePath2;
	
	private IfcSchema schema;
	private List<Entry<String, IfcModel>> models;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Main main = null;

		try {

			main = new Main(args);
			main.run();

		} catch (Throwable e) {
			e.printStackTrace();
			while ((e = e.getCause()) != null) {
				e.printStackTrace();
			}
		} finally {
			
			if (main != null) {
				
				if (main.jenaModelFactoryBase != null) {
					try {
						main.jenaModelFactoryBase.releaseAll();
					} catch (Exception e) {
						logger.error("Error releasing objects", e);
					}
				}
				
			}
			
		}
	}
	
	private Main(String[] args) {
		
		for (int i = 0; i < args.length; ++i) {
			String argName = args[i];
			switch (argName) {
			case ARG_LOGGER_PROPERTIES:
			case ARG_LOGGER_PROPERTIES_SHORT:
				if (++i < args.length) {
					loggerPropertiesFilePath = args[i];
				} else {
					throw new IllegalArgumentException(String.format("%s%n%s", "Logger properties file path is expected", ARG_SYNTAX));
				}
				break;
			case ARG_CONFIG:
			case ARG_CONFIG_SHORT:
				if (++i < args.length) {
					configFilePath = args[i];
				} else {
					throw new IllegalArgumentException(String.format("%s%n%s", "Configuration file path is expected", ARG_SYNTAX));
				}
				break;
			case ARG_SCHEMA:
			case ARG_SCHEMA_SHORT:
				if (++i < args.length) {
					schemaFilePath = args[i];
				} else {
					throw new IllegalArgumentException(String.format("%s%n%s", "Schema file path is expected", ARG_SYNTAX));
				}
				break;
			case ARG_MODEL:
			case ARG_MODEL_SHORT:
				if (++i < args.length) {
					modelFilePath = args[i];
				} else {
					throw new IllegalArgumentException(String.format("%s%n%s", "Model file path is expected", ARG_SYNTAX));
				}
				break;
			case ARG_MODEL2:
			case ARG_MODEL2_SHORT:
				if (++i < args.length) {
					modelFilePath2 = args[i];
				} else {
					throw new IllegalArgumentException(String.format("%s%n%s", "Model-2 file path is expected", ARG_SYNTAX));
				}
				break;
			}
		}
		
		if (loggerPropertiesFilePath == null) {
			throw new IllegalArgumentException(String.format("%s%n%s", "Logger properties file path is expected", ARG_SYNTAX));			
		}
	}
	
	protected void run() throws Exception {
		
		//
		// setup org.apacher.log4j.Logger
		//
		if (loggerPropertiesFilePath.endsWith("xml")) {
			DOMConfigurator.configure(loggerPropertiesFilePath);			
		} else {
			PropertyConfigurator.configure(loggerPropertiesFilePath);			
		}
		
		//
		// load configuration document
		//
		logger.info(String.format("Loading configuration in '%s'", configFilePath));
		ConfigurationDocument.load(configFilePath);
		logger.info("Loading configuration has been completed successfully");
		
		ConfigurationPool<ConfigurationItemEx> jenaModelConfigurations = JenaModelFactoryPoolConfigurationSection.getInstance().getConfigurationPool(); 
		ConfigurationItemEx jenaModelConfiguration = jenaModelConfigurations.getDefault();
		jenaModelFactoryBase = JenaModelFactoryBase.getFactory(jenaModelConfiguration);

		schema = IfcParserUtil.parseSchema(schemaFilePath);
		
		Model schemaGraph = jenaModelFactoryBase.createModel(schema.getVersion());
		
		Ifc2RdfExportUtil.exportSchemaToJenaModel(schemaGraph, schema, null);		
		
		schemaGraph.write(new FileWriter("schema.owl"), "N3");
		
		
		//
		// Set default IFC-to-RDF conversion context
		//	
//		createIfc2RdfSchemaConverter(schema, null);		
		
		models = new ArrayList<>();
		
		//
		// Parsing models
		//
		if (modelFilePath != null) {			
			IfcModel model = IfcParserUtil.parseModel(modelFilePath);
			String name = RegexUtils.getHtmlSafeName(new File(modelFilePath).getName());
			models.add(new Pair<String, IfcModel>(name,  model));
		}
		
		if (modelFilePath2 != null) {			
			IfcModel model = IfcParserUtil.parseModel(modelFilePath2);
			String name = RegexUtils.getHtmlSafeName(new File(modelFilePath2).getName());
			models.add(new Pair<String, IfcModel>(name,  model));
		}		
		
		
//		MemoryJenaModelFactory memoryJenaFactory = new MemoryJenaModelFactory();

		if (!models.isEmpty()) {			
			
			//
			// Get default grounding rule sets
			//
			ComplexProcessorConfiguration groundingConfiguration = IfcModelAnalyzerUtil.getDefaultGroundingRuleSets();
			String groundingConfigurationName = groundingConfiguration.getName();
			
			List<Entry<String, RdfMsgContainer>> structuredMsgContainerMap = new ArrayList<>();
			
			for (Entry<String, IfcModel> entry : models) {
				String name = entry.getKey();
				
				IfcModel model = entry.getValue();
				IfcModelAnalyzerUtil.groundModel(model, groundingConfiguration);
				
				Model modelGraph = jenaModelFactoryBase.getModel(name);
				if (!RELOAD_DATA_FROM_DATABASE || modelGraph.isEmpty()) {
					Ifc2BinaryFileExportUtil.exportModelToJenaModel(modelGraph, model, null);
				}

				File modelDirectory = FileManager.createDirectory(name);				
				File groundingSetDirectory = FileManager.createDirectory(FileManager.createFileName(modelDirectory, groundingConfigurationName));				
				
				modelGraph.write(new FileWriter("model.rdf"), "N3");
				

// TODO: Uncomment this fragment
//				IRdfModel rdfModel = new JenaModelAdapter(modelGraph);
//				RdfMsgContainer rdfMsgContainer = ModelAnalyzerUtil.splitToStructuredMsgs(rdfModel);
//				
//				ModelAnalyzerUtil.exportStructuredMsgs(rdfMsgContainer, FileManager.createFileName(groundingSetDirectory, "structuredMsgs_%s.txt"));
//				ModelAnalyzerUtil.exportStructuredMsgsStatistics(rdfMsgContainer, FileManager.createFileName(groundingSetDirectory, "structuredMsgs_statistics.txt"));
//				
//				structuredMsgContainerMap.add(new Pair<String, RdfMsgContainer>(name, rdfMsgContainer));
			}
			
			if (structuredMsgContainerMap.size() == 2) {
				
				File compareDirectory = FileManager.createDirectory(
						String.format("%s_%s", structuredMsgContainerMap.get(0).getKey(), structuredMsgContainerMap.get(1).getKey()));
				IfcModelAnalyzerUtil.compareVersions(structuredMsgContainerMap, FileManager.createFileName(compareDirectory, "%%s_%s.txt"));
			}
			
		}

		logger.info("END OF PROGRAM");
		
	}
	
	
//	private void logError(Object message, Throwable t) {
//	logger.error(message, t);
//	Logger.getLogger(t.getClass()).error(message, t);
//}

	
	protected void testSchema(IfcSchema schema) {
		for (IfcEntityTypeInfo entityInfo : schema.getEntityTypeInfos()) {
			for (IfcInverseLinkInfo inverseLinkInfo : entityInfo.getInverseLinkInfos()) {
				if (inverseLinkInfo.getCardinality().isSingle() && !inverseLinkInfo.getCardinality().isOptional()) {
					IfcLinkInfo outgoingLinkInfo = inverseLinkInfo.getOutgoingLinkInfo();
					if (outgoingLinkInfo.getCardinality().isSingle()) {
						System.out.println(String.format("%s.%s<--%s.%s", inverseLinkInfo
								.getDestinationEntityTypeInfo().getName(), inverseLinkInfo.getName(), outgoingLinkInfo
								.getEntityTypeInfo().getName(), outgoingLinkInfo.getName()));
					}
				}
			}
		}
	}


}