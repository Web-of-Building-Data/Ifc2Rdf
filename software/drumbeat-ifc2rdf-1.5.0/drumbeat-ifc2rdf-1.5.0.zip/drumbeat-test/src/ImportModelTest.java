import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

import net.linkedbuildingdata.ifc.IfcNotFoundException;
import net.linkedbuildingdata.ifc.convert.step2ifc.IfcParserException;
import net.linkedbuildingdata.ifc.convert.step2ifc.IfcSchemaParser;
import net.linkedbuildingdata.ifc.data.model.*;
import net.linkedbuildingdata.ifc.data.schema.*;

import org.openrdf.repository.RepositoryException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.franz.agraph.jena.*;
import com.franz.agraph.repository.*;
import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.vocabulary.OWL;
import com.hp.hpl.jena.vocabulary.RDF;


public class ImportModelTest {
	
	//////////////////////////////////////////////
	// STATIC MEMBERS 
	//////////////////////////////////////////////
	
	//static private final String SERVER_URL = "http://volume376.allegrograph.net:10035";
	static private final String SERVER_URL = "http://murskain.cs.hut.fi:10035";
	static private final String REPOSITORY_ID = "Hotel-1.0";
	static private final String USERNAME = "test";
	static private final String PASSWORD = "xyz";
//	static private final String TEMPORARY_DIRECTORY = "";
	
//	static private final String MODEL_BASE_URI = "http://drum.cs.hut.fi/model/";
	static private final String IFC_BASE_URI = "http://drum.cs.hut.fi/schema/IFC2X3#";
	static private final String IFC_SCHEMA_FILE_PATH = "c:\\DRUM\\!git\\Resources\\Specifications\\IFC\\IFC2X3_TC1.exp";

	private static final Logger logger = Logger.getRootLogger();

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		logger.setLevel(Level.ALL);
		
		ImportModelTest test = new ImportModelTest();
		
		try {
		
			test.model = test.getModel();
			AGReasoner reasoner = new AGReasoner();
			test.infModel = new AGInfModel(reasoner, test.model);
			test.schema = test.parseSchema();
			
			test.parseModel();
			
//			model.removeAll();
			
			System.out.println("Program completed");
			
		} catch (Throwable e) {
			e.printStackTrace();
			while ((e = e.getCause()) != null) {
				e.printStackTrace();
			}
			
		} finally {
			
			if (test.connection != null) {
				try {
					test.connection.close();
				} catch (RepositoryException e) {
					e.printStackTrace();
				}
			}
			
		}
		
	}
	
	//////////////////////////////////////////////
	// NON-STATIC MEMBERS 
	//////////////////////////////////////////////

	private AGRepositoryConnection connection;
	private IfcSchema schema;
	private AGModel model;
	private AGInfModel infModel;
	private Map<String, IfcEntity> entityMap = new HashMap<>();
	
	private AGModel getModel() throws RepositoryException {
		
		AGServer server = new AGServer(SERVER_URL, USERNAME, PASSWORD);
		AGCatalog catalog = server.getRootCatalog();
		
		AGRepository myRepository = catalog.createRepository(REPOSITORY_ID);
		myRepository.initialize();
		AGRepositoryConnection connection = myRepository.getConnection();
		AGGraphMaker graphMaker = new AGGraphMaker(connection);
		AGGraph graph = graphMaker.getGraph();
		AGModel model = new AGModel(graph);
		return model;
	}
	
	private IfcSchema parseSchema() throws IfcParserException, FileNotFoundException {
		
		return IfcSchemaParser.parse(new FileInputStream(IFC_SCHEMA_FILE_PATH));
		
	}
	
	private void parseModel() throws IfcNotFoundException {
		
		StmtIterator statements = model.listStatements(
				null, OWL.Class.as(Property.class), (Resource)null);
		
		while (statements.hasNext()) {
			Statement statement = statements.next();
			parseEntity(statement);
		}
		
	}
	
	private IfcEntity parseEntity(Statement statement) throws IfcNotFoundException {		
		
		RDFNode object = statement.getObject();
		if (!object.isURIResource()) {
			return null;
		}
		
		String typeUri = ((Resource)object).getURI();
		
		if (!typeUri.startsWith(IFC_BASE_URI + "Ifc")) {
			return null;
		}
		
		Resource subject = statement.getSubject();
		String entityName = subject.toString();
		
		IfcEntity entity = entityMap.get(entityName);
		if (entity != null) {
			return entity;
		}		
		
		String entityTypeName = typeUri.substring(IFC_BASE_URI.length());
		IfcEntityTypeInfo entityTypeInfo = schema.getEntityTypeInfo(entityTypeName);
		
		System.out.println(String.format("Parsing entity: %s, type: %s", entityName, entityTypeName));
		
		entity = new IfcEntity(entityTypeInfo, 0);
		
		if (subject.isURIResource()) {
			entity.setName(subject.getLocalName());
		}
		
		entityMap.put(subject.toString(), entity);
		
		StmtIterator properties = subject.listProperties();
		
		while (properties.hasNext()) {
			statement = properties.next();
			
			Property property = statement.getPredicate();
			if (!property.getURI().startsWith(IFC_BASE_URI)) {
				continue;
			}
			
			String attributeName = property.getLocalName();
			if (attributeName.contains("_")) {
				attributeName = attributeName.substring(0, attributeName.indexOf('_'));
			}
			if (attributeName.equalsIgnoreCase("rawName")) {
				continue;
			}
			
			
			IfcAttributeInfo attributeInfo = entityTypeInfo.getAttributeInfo(attributeName);
			int attributeIndex = entityTypeInfo.getAttributeInfos().indexOf(attributeInfo);
			
			object = statement.getObject();
			
			if (object.isLiteral()) {
				
				IfcLiteralValue value = parseLiteral((Literal)object);
				IfcLiteralAttribute attribute = new IfcLiteralAttribute(attributeInfo, attributeIndex, value);
				entity.addLiteralAttribute(attribute);
//				System.out.println(String.format("%s %s %s", entity, attributeInfo, value));
				
			} else {
				
				assert(object.isResource());
				Resource valueResource = (Resource)object;
				
				Statement valueClassStatement = valueResource.getProperty( OWL.Class.as(Property.class));				
				
				if (valueClassStatement != null) {
					Resource valueClassResource = valueClassStatement.getObject().asResource();				
					if (!valueClassResource.equals(RDF.List)) {
						IfcEntity entityValue = parseEntity(valueClassStatement);
						IfcLink outgoingLink = new IfcLink((IfcLinkInfo)attributeInfo, attributeIndex, entity, entityValue);
						entity.addOutgoingLink(outgoingLink);
					} else {
						if (attributeInfo instanceof IfcLinkInfo) {
							IfcEntityList entityList = new IfcEntityList();
							parseEntityList(valueResource, entityList);
							IfcLink outgoingLink = new IfcLink((IfcLinkInfo)attributeInfo, attributeIndex, entity, entityList);
							entity.addOutgoingLink(outgoingLink);
						} else {
							IfcLiteralValueList literalList = new IfcLiteralValueList();
							parseLiteralList(valueResource, literalList);
							IfcLiteralAttribute literalAttribute = new IfcLiteralAttribute(attributeInfo, attributeIndex, literalList);
							entity.addLiteralAttribute(literalAttribute);
						}
					}
					
				}
					
			}
			
		}		
		
		return entity;
	}
	
	private static IfcLiteralValue parseLiteral(Literal literal) {
		//RDFDatatype datatype = literal.getDatatype();
		//if (datatype.)
		return new IfcLiteralValue(literal.getString(), IfcTypeEnum.STRING);
	}
	
	private void parseEntityList(Resource valueResource, IfcEntityList entityList) throws IfcNotFoundException {
		
		while (!valueResource.equals(RDF.nil)) {
			StmtIterator listStatements = valueResource.listProperties();
			while (listStatements.hasNext()) {
				Statement statement = listStatements.next();
				if (statement.getPredicate().equals(RDF.first)) {
					Resource resource = statement.getObject().asResource();
					statement = resource.getProperty(OWL.Class.as(Property.class));
					IfcEntity entity = parseEntity(statement);
					entityList.add(entity);
				} else {
					assert (statement.getPredicate().equals(RDF.rest));
					valueResource = statement.getObject().asResource();
				}
			}
		}
	}
	
	private void parseLiteralList(Resource valueResource, IfcLiteralValueList literalList) throws IfcNotFoundException {
		
		while (!valueResource.equals(RDF.nil)) {
			StmtIterator listStatements = valueResource.listProperties();
			while (listStatements.hasNext()) {
				Statement statement = listStatements.next();
				if (statement.getPredicate().equals(RDF.first)) {
					IfcLiteralValue literal = parseLiteral((Literal)statement.getObject());
					literalList.add(literal);
				} else {
					assert (statement.getPredicate().equals(RDF.rest));
					valueResource = statement.getObject().asResource();
				}
			}
		}
	}
}
